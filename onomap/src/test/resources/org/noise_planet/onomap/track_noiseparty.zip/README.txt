Esporta la descrizione dell'archivio

 i file meta.properties contengono informazioni generali sul dispositivo:
 - version_name Versione (Major, minor e revision)
 - build_date Data dell'assemblaggio dell'APK
 - version_number Numero intero con la versione dell'applicazione
 - time_length Durata dei record in secondi
 - uuid Identificatore casuale fissato al primo avvio dell'applicazione
 - leq_mean Livello di rumore equivalente medio in dB(A) della misurazione
 - record_utc Ora del record in millisecondi dall'epoca
 - device_manufacturer device_model device_product Generiche informazioni hardware sul dispositivo di misura
 - pleasantness Piacevolezza dell'input utente 1-100
 - tags Valori separati da virgole dei tag selezionati dall'utente (solo in inglese)
 - user_profile Conoscenza dell'utente in acustica NONE, NOVICE, EXPERT
 - noiseparty_tag l'identificatore NoiseParty

 track.geojson Campioni da 1 secondo delle misurazioni. In formato geojson (http://geojson.io)
 - leq_mean Livello di rumore equivalente medio a 1 secondo in dB(A)
 - accuracy Precisione della localizzazione in metri (fornita da gps, rete o gsm)
 - location_utc Ora della localizzazione in millisecondi dall'epoca
 - leq_utc Ora della misurazione in millisecondi dall'epoca
 - leq_id Identificatore univoco del record
 - marker_color Colore usato da geojson.io
 - bearing Orientazione del movimento. Vedi https://developer.android.com/reference/android/location/Location.html#getBearing()
 - speed Velocità del dispositivo stimata in m/s
 - leq_frequency Livello di rumore equivalente medio a 1 secondo in dB(A) per la frequenza specificata
