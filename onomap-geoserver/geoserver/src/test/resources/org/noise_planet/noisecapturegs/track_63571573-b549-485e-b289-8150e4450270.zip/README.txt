Description du contenu de l'archive

 meta.properties file are general info on device and record:
 - Numéro de version de l'application: version_name Majeur, mineur et revision
 - build_date: Date du build de l'application
 - version_number: Numero de la version (entier)
 - time_length: Durée de l'enregistrement en secondes
 - uuid: Identifiant aléatoire au lancement de l'application
 - leq_mean: Moyenne du Leq (niveau sonore équivalent) sur la durée de l'enregistrement
 - record_utc: Durée de l'enregistrement en milliseconde (epoch)
 - device_manufacturer device_model device_product: Information sur le matériel
 - pleasantness: Pourcentage d'agrément (0-100)
 - tags: Liste des tags séparés par une virgule (english only)
 - user_profile: Connaissance de l'utilisateur vis à vis de l'acoustique (NONE, NOVICE, EXPERT)
 - noiseparty_tag: Identifiant de la NoiseParty

 track.geojson échantillons mesurés chaque seconde au format geojson (http://geojson.io)
 - leq_mean: Niveau sonore équivalent 1s en dB(A)
 - accuracy: Précision de la localisation GPS en m (valeur fournie par le GPS, le réseau ou le GSM)
 - location_utc: référence UTC en milliseconde (epoch)
 - leq_utc: Heure de la mesure en milliseconde (epoch)
 - leq_id: Identifiant unique de la mesure
 - marker_color: Couleur utilisée par geojson.io
 - bearing: Orientation horizontale du téléphone. Voir https://developer.android.com/reference/android/location/Location.html#getBearing()
 - speed: Estimation de la vitesse en m/s
 - leq_frequency: Leq 1s par fréquence
